package com.loophack.app

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView

/** Окно настройки отправителя уведомления: ник, текст и аватарка. */
class NotifyActivity : Activity() {

    private lateinit var avatarHolder: FrameLayout
    private lateinit var nameEt: EditText
    private lateinit var textEt: EditText

    private fun d(v: Int) = Ui.dp(this, v)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        build()
    }

    private fun field(hint: String, value: String): EditText {
        val e = EditText(this)
        e.setText(value)
        e.hint = hint
        e.setSingleLine(false)
        e.maxLines = 3
        e.setTextColor(Ui.WHITE)
        e.setHintTextColor(Ui.GRAY)
        e.background = Ui.rounded(Ui.PANEL2, d(12).toFloat(), 0x33B8A8C8, d(1))
        e.setPadding(d(12), d(10), d(12), d(10))
        return e
    }

    private fun refreshAvatar() {
        avatarHolder.removeAllViews()
        avatarHolder.addView(Avatar.make(this), FrameLayout.LayoutParams(d(72), d(72)))
    }

    private fun build() {
        val root = FrameLayout(this)
        root.setOnClickListener { finish() }

        val card = Ui.card(this)
        card.isClickable = true
        card.setPadding(d(18), d(16), d(18), d(18))

        card.addView(Ui.text(this, "Отправитель уведомления", 18f, Ui.WHITE, true))
        card.addView(
            Ui.text(this, "Так будет выглядеть уведомление на стриме.", 12f, Ui.GRAY),
            Ui.lin(Ui.WRAP, Ui.WRAP, 0f, 0, d(2), 0, d(12))
        )

        // Аватарка
        val av = LinearLayout(this)
        av.orientation = LinearLayout.HORIZONTAL
        av.gravity = Gravity.CENTER_VERTICAL
        avatarHolder = FrameLayout(this)
        av.addView(avatarHolder, Ui.lin(d(72), d(72), 0f, 0, 0, d(14), 0))
        val btns = LinearLayout(this)
        btns.orientation = LinearLayout.VERTICAL
        btns.addView(Ui.button(this, "Выбрать аватар", 1) { pickAvatar() }, Ui.lin(Ui.MATCH, Ui.WRAP))
        btns.addView(
            Ui.button(this, "Вернуть логотип", 1) {
                Repo.setNotifyAvatar(this, "")
                refreshAvatar()
            },
            Ui.lin(Ui.MATCH, Ui.WRAP, 0f, 0, d(8), 0, 0)
        )
        av.addView(btns, Ui.lin(0, Ui.WRAP, 1f))
        card.addView(av)
        refreshAvatar()

        card.addView(Ui.text(this, "ОТ КОГО", 12f, Ui.PINK, true), Ui.lin(Ui.WRAP, Ui.WRAP, 0f, 0, d(16), 0, d(6)))
        nameEt = field("Ник отправителя", Repo.notifyName(this))
        card.addView(nameEt, Ui.lin(Ui.MATCH, Ui.WRAP))

        card.addView(Ui.text(this, "ТЕКСТ", 12f, Ui.PINK, true), Ui.lin(Ui.WRAP, Ui.WRAP, 0f, 0, d(14), 0, d(6)))
        textEt = field("Текст уведомления", Repo.notifyText(this))
        card.addView(textEt, Ui.lin(Ui.MATCH, Ui.WRAP))

        card.addView(
            Ui.row(
                this,
                Ui.button(this, "Отмена", 1) { finish() },
                Ui.button(this, "Сохранить", 0) { save() }
            ),
            Ui.lin(Ui.MATCH, Ui.WRAP, 0f, 0, d(18), 0, 0)
        )

        val scroll = ScrollView(this)
        scroll.addView(card, FrameLayout.LayoutParams(Ui.MATCH, Ui.WRAP))
        val lp = FrameLayout.LayoutParams(Ui.MATCH, Ui.WRAP, Gravity.CENTER)
        lp.setMargins(d(18), d(18), d(18), d(18))
        root.addView(scroll, lp)
        setContentView(root)
        Ui.reveal(card)
    }

    private fun pickAvatar() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
        i.addCategory(Intent.CATEGORY_OPENABLE)
        i.type = "image/*"
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        try {
            startActivityForResult(i, 11)
        } catch (e: Exception) {
            Ui.toast(this, "Не удалось открыть галерею")
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != 11 || resultCode != RESULT_OK) return
        val u = data?.data ?: return
        try {
            contentResolver.takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        } catch (e: Exception) {
            // Не все провайдеры поддерживают постоянный доступ.
        }
        Repo.setNotifyAvatar(this, u.toString())
        refreshAvatar()
    }

    private fun save() {
        val n = nameEt.text.toString().trim()
        val t = textEt.text.toString().trim()
        if (n.isEmpty() || t.isEmpty()) {
            Ui.toast(this, "Заполните ник и текст")
            return
        }
        Repo.setNotifyName(this, n)
        Repo.setNotifyText(this, t)
        OverlayService.refresh()
        finish()
        if (OverlayService.running) {
            Handler(Looper.getMainLooper()).postDelayed({ OverlayService.previewNotify() }, 500)
        }
    }
}
