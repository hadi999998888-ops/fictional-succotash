package com.loophack.app

import android.content.Context
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout

/** Блок «Уведомление для стримов»: используется и в приложении, и в оверлей-меню. */
object NotifyPanel {

    fun build(ctx: Context): View {
        fun dp(v: Int) = Ui.dp(ctx, v)

        val card = Ui.card(ctx)

        val caption = Ui.text(ctx, "", 12f, Ui.GRAY)
        fun refreshCaption() {
            caption.text = "Каждые ${Repo.notifyInterval(ctx)} сек приходит уведомление"
        }
        refreshCaption()

        card.addView(
            Ui.toggle(ctx, "Уведомление для стримов", Repo.notifyEnabled(ctx)) { on ->
                Repo.setNotifyEnabled(ctx, on)
                OverlayService.refreshNotifier()
                if (on && !OverlayService.running) {
                    Ui.toast(ctx, "Заработает после нажатия СТАРТ")
                }
            }
        )
        card.addView(caption)

        // Предпросмотр: как выглядит отправитель
        val prev = LinearLayout(ctx)
        prev.orientation = LinearLayout.HORIZONTAL
        prev.gravity = Gravity.CENTER_VERTICAL
        prev.background = Ui.rounded(Ui.PANEL2, dp(14).toFloat(), 0x33B8A8C8, dp(1))
        prev.setPadding(dp(10), dp(8), dp(12), dp(8))
        prev.addView(Avatar.make(ctx), Ui.lin(dp(38), dp(38), 0f, 0, 0, dp(10), 0))
        val col = LinearLayout(ctx)
        col.orientation = LinearLayout.VERTICAL
        col.addView(Ui.text(ctx, Repo.notifyName(ctx), 13f, Ui.WHITE, true))
        col.addView(Ui.text(ctx, Repo.notifyText(ctx), 12f, Ui.GRAY))
        prev.addView(col, Ui.lin(0, Ui.WRAP, 1f))
        card.addView(prev, Ui.lin(Ui.MATCH, Ui.WRAP, 0f, 0, dp(10), 0, 0))

        card.addView(
            Ui.seek(ctx, "Интервал", 8, 120, Repo.notifyInterval(ctx), { "$it сек" }) { v ->
                Repo.setNotifyInterval(ctx, v)
                refreshCaption()
                OverlayService.refreshNotifier()
            }
        )

        card.addView(
            Ui.row(
                ctx,
                Ui.chip(ctx, "✎ Отправитель и аватар") { Nav.openNotify(ctx) },
                Ui.chip(ctx, "▶ Показать пример") {
                    if (OverlayService.running) OverlayService.previewNotify()
                    else Ui.toast(ctx, "Сначала нажмите СТАРТ")
                }
            ),
            Ui.lin(Ui.MATCH, Ui.WRAP, 0f, 0, dp(8), 0, 0)
        )
        return card
    }
}
