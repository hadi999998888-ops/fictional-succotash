package com.loophack.app

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.Uri

object Links {
    const val TELEGRAM = "https://t.me/ExtraCheatStanddof2"

    /** Просто открывает ссылку: Telegram, если установлен, иначе браузер. Возвращает true, если открылось. */
    fun openTelegram(c: Context): Boolean {
        return try {
            c.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(TELEGRAM)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            true
        } catch (e: Exception) {
            Ui.toast(c, "Не удалось открыть ссылку")
            false
        }
    }

    /** after вызывается только если ссылка действительно открылась. */
    fun telegramButton(c: Context, after: () -> Unit = {}) =
        Ui.button(c, "✈  НАШ TELEGRAM-КАНАЛ", 0) {
            if (openTelegram(c)) after()
        }
}

/** Запуск вспомогательных экранов и из приложения, и из оверлея (сервис). */
object Nav {
    fun openEditor(c: Context, id: String?) {
        val i = Intent(c, EditorActivity::class.java)
        if (id != null) i.putExtra("id", id)
        if (c !is Activity) i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        c.startActivity(i)
    }

    fun openNotify(c: Context) {
        val i = Intent(c, NotifyActivity::class.java)
        if (c !is Activity) i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        c.startActivity(i)
    }

    fun pickMedia(c: Context, type: String) {
        val i = Intent(c, PickerActivity::class.java).putExtra("type", type)
        if (c !is Activity) i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        c.startActivity(i)
    }
}

object Help {
    const val INSTRUCTION =
        "1. Нажмите «СТАРТ» и выдайте разрешение «Поверх других приложений».\n\n" +
                "2. Внизу экрана появится стрелка ⌃. Зажмите её и проведите пальцем вверх — откроется меню оверлея. " +
                "Стрелку можно сдвинуть пальцем влево или вправо.\n\n" +
                "3. В меню добавьте текст, фото или видео. Элемент двигается одним пальцем, " +
                "масштабируется и вращается двумя.\n\n" +
                "4. «Закрепить» фиксирует элемент на месте. Прозрачность остаётся такой, как вы её задали.\n\n" +
                "5. Кнопка «—» в меню убирает его вниз, чтобы не мешало. Чтобы вернуть меню, " +
                "снова зажмите стрелку и проведите вверх.\n\n" +
                "6. Рекламный щит LOOP HACK можно убрать и вернуть переключателем в меню.\n\n" +
                "7. Откройте TikTok и начните стрим с демонстрацией экрана — все элементы видны поверх."
}
