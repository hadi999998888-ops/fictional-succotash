package com.loophack.app

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {

    companion object {
        const val REQ_NOTIF = 4
    }

    private var statusChip: TextView? = null
    private var startBtn: TextView? = null
    private var lockBtn: TextView? = null
    private var countText: TextView? = null
    private var list: LinearLayout? = null
    private var mainBuilt = false
    private var pendingStart = false
    private var askedNotif = false

    private fun d(v: Int) = Ui.dp(this, v)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Repo.ensureLogo(this)
    }

    override fun onResume() {
        super.onResume()
        if (!Repo.gateOpen(this)) {
            mainBuilt = false
            buildGate()
            return
        }
        if (!mainBuilt) {
            buildMain()
            mainBuilt = true
        }
        if (!askedNotif) {
            askedNotif = true
            if (Build.VERSION.SDK_INT >= 33 &&
                checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
            ) {
                requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), REQ_NOTIF)
            }
        }
        if (pendingStart) {
            pendingStart = false
            if (Settings.canDrawOverlays(this)) launchService()
            else Ui.toast(this, "Разрешение не выдано — оверлеи не запущены")
        }
        updateAll()
    }

    // ------------------------------------------------------------------ экран-замок

    private fun buildGate() {
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.gravity = Gravity.CENTER
        root.setBackgroundColor(Ui.BLACK)
        root.setPadding(d(28), d(28), d(28), d(28))

        root.addView(Ui.logo(this, 34), Ui.lin(d(150), d(150)))
        val title = Ui.text(this, "LOOP HACK", 32f, Ui.WHITE, true)
        title.setShadowLayer(d(12).toFloat(), 0f, 0f, Ui.PINK)
        root.addView(title, Ui.lin(Ui.WRAP, Ui.WRAP, 0f, 0, d(18), 0, 0))
        root.addView(
            Ui.text(this, "Overlay Studio для TikTok-стримов", 14f, Ui.GRAY),
            Ui.lin(Ui.WRAP, Ui.WRAP, 0f, 0, d(4), 0, 0)
        )
        val msg = Ui.text(
            this,
            "Чтобы открыть приложение, перейдите в наш Telegram-канал.\n" +
                    "Достаточно просто нажать кнопку — после перехода приложение откроется.",
            14f, Ui.WHITE
        )
        msg.gravity = Gravity.CENTER
        msg.setLineSpacing(0f, 1.15f)
        root.addView(msg, Ui.lin(Ui.MATCH, Ui.WRAP, 0f, 0, d(26), 0, d(22)))

        val btn = Links.telegramButton(this) { Repo.openGate(this) }
        btn.setPadding(d(12), d(18), d(12), d(18))
        btn.textSize = 16f
        root.addView(btn, Ui.lin(Ui.MATCH, Ui.WRAP))
        setContentView(root)
        Ui.reveal(root.getChildAt(0), root.getChildAt(1), root.getChildAt(2), msg, btn)
    }

    // ------------------------------------------------------------------ главный экран

    private fun LinearLayout.put(v: View, top: Int = 12) {
        addView(v, Ui.lin(Ui.MATCH, Ui.WRAP, 0f, 0, d(top), 0, 0))
    }

    private fun buildMain() {
        val scroll = ScrollView(this)
        scroll.setBackgroundColor(Ui.BLACK)
        scroll.isFillViewport = true
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(d(16), d(18), d(16), d(28))
        scroll.addView(col, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        // Шапка
        val head = LinearLayout(this)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        head.addView(Ui.logo(this, 15), Ui.lin(d(54), d(54), 0f, 0, 0, d(12), 0))
        val titles = LinearLayout(this)
        titles.orientation = LinearLayout.VERTICAL
        val title = Ui.text(this, "LOOP HACK", 24f, Ui.WHITE, true)
        title.setShadowLayer(d(9).toFloat(), 0f, 0f, Ui.PINK)
        titles.addView(title)
        titles.addView(Ui.text(this, "Overlay Studio · TikTok", 12f, Ui.GRAY))
        head.addView(titles, Ui.lin(0, Ui.WRAP, 1f))
        val chip = Ui.text(this, "", 11f, Ui.GRAY, true)
        chip.setPadding(d(10), d(6), d(10), d(6))
        chip.background = Ui.rounded(Ui.PANEL, d(10).toFloat(), 0x33B8A8C8, d(1))
        statusChip = chip
        head.addView(chip)
        col.addView(head)

        // Главная карточка со СТАРТ
        val hero = Ui.card(this)
        val sb = Ui.button(this, "▶  СТАРТ", 0) { onStartStop() }
        sb.textSize = 20f
        sb.setPadding(d(12), d(22), d(12), d(22))
        startBtn = sb
        hero.addView(sb, Ui.lin(Ui.MATCH, Ui.WRAP))
        val hint = Ui.text(
            this,
            "Внизу экрана появится стрелка ⌃. Зажмите её и проведите вверх — откроется меню оверлея.",
            12f, Ui.GRAY
        )
        hint.setPadding(0, d(10), 0, 0)
        hero.addView(hint)
        col.put(hero, 16)

        // Добавить
        val addCard = Ui.card(this)
        addCard.addView(Ui.sectionTitle(this, "ДОБАВИТЬ НА ЭКРАН"))
        addCard.addView(
            Ui.row(
                this,
                Ui.button(this, "Aa  Текст", 1) { Nav.openEditor(this, null) },
                Ui.button(this, "Фото", 1) { Nav.pickMedia(this, Type.IMAGE) },
                Ui.button(this, "Видео", 1) { Nav.pickMedia(this, Type.VIDEO) }
            ),
            Ui.lin(Ui.MATCH, Ui.WRAP, 0f, 0, d(10), 0, 0)
        )
        col.put(addCard)

        // Уведомление для стримов
        val notify = NotifyPanel.build(this)
        col.put(notify)

        // Элементы
        val el = Ui.card(this)
        val eh = LinearLayout(this)
        eh.orientation = LinearLayout.HORIZONTAL
        eh.gravity = Gravity.CENTER_VERTICAL
        eh.addView(Ui.sectionTitle(this, "ЭЛЕМЕНТЫ"), Ui.lin(0, Ui.WRAP, 1f))
        val cnt = Ui.text(this, "0", 12f, Ui.GRAY, true)
        countText = cnt
        eh.addView(cnt)
        el.addView(eh)
        val lock = Ui.chip(this, "Закрепить всё") { toggleLockAll() }
        lockBtn = lock
        el.addView(
            Ui.row(this, lock, Ui.chip(this, "Удалить всё") { confirmDeleteAll() }),
            Ui.lin(Ui.MATCH, Ui.WRAP, 0f, 0, d(10), 0, 0)
        )
        val lst = LinearLayout(this)
        lst.orientation = LinearLayout.VERTICAL
        list = lst
        el.addView(lst, Ui.lin(Ui.MATCH, Ui.WRAP, 0f, 0, d(10), 0, 0))
        col.put(el)

        // Инструкция, Telegram, настройки
        val help = Ui.expandable(this, "Инструкция", Help.INSTRUCTION)
        col.put(help)
        val tg = Links.telegramButton(this)
        col.put(tg, 14)
        val st = Ui.chip(this, "Настройки") { startActivity(Intent(this, SettingsActivity::class.java)) }
        col.put(st, 10)

        setContentView(scroll)
        Ui.reveal(head, hero, addCard, notify, el, help, tg, st)
    }

    private fun updateAll() {
        val running = OverlayService.running
        val perm = Settings.canDrawOverlays(this)
        statusChip?.let {
            it.text = if (running) "● ВКЛЮЧЕНО" else "○ ВЫКЛЮЧЕНО"
            it.setTextColor(if (running) Ui.PINK else Ui.GRAY)
        }
        startBtn?.let {
            val r = d(14).toFloat()
            if (running) {
                it.text = "■  СТОП"
                it.background = Ui.rounded(Ui.DANGER, r)
            } else {
                it.text = if (perm) "▶  СТАРТ" else "▶  СТАРТ  (нужно разрешение)"
                it.background = Ui.gradient(r)
            }
        }
        val items = Repo.load(this)
        countText?.text = "${items.size}"
        lockBtn?.text = if (items.isNotEmpty() && items.all { it.locked }) "Открепить всё" else "Закрепить всё"
        rebuildList(items)
    }

    private fun rebuildList(items: List<Item>) {
        val l = list ?: return
        l.removeAllViews()
        if (items.isEmpty()) {
            l.addView(Ui.text(this, "Пока пусто. Добавьте текст, фото или видео.", 13f, Ui.GRAY))
            return
        }
        // Сверху — самый верхний слой.
        for (item in items.reversed()) {
            l.addView(
                ItemPanel.card(this, item) { updateAll() },
                Ui.lin(Ui.MATCH, Ui.WRAP, 0f, 0, 0, 0, d(10))
            )
        }
    }

    // ------------------------------------------------------------------ действия

    private fun onStartStop() {
        if (OverlayService.running) {
            OverlayService.stop(this)
            Ui.toast(this, "Оверлеи остановлены")
            startBtn?.postDelayed({ updateAll() }, 400)
            return
        }
        if (!Settings.canDrawOverlays(this)) {
            AlertDialog.Builder(this)
                .setTitle("Нужно разрешение")
                .setMessage(
                    "Чтобы показывать элементы поверх TikTok, включите для LOOP HACK " +
                            "переключатель «Поверх других приложений», затем вернитесь назад."
                )
                .setPositiveButton("Открыть настройки") { _, _ ->
                    pendingStart = true
                    startActivity(
                        Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
                    )
                }
                .setNegativeButton("Отмена", null)
                .show()
            return
        }
        launchService()
    }

    private fun launchService() {
        try {
            OverlayService.start(this)
            Ui.toast(this, "Готово! Зажмите стрелку внизу экрана и проведите вверх")
            startBtn?.postDelayed({ updateAll() }, 500)
            startBtn?.postDelayed({ moveTaskToBack(true) }, 900)
        } catch (e: Exception) {
            Ui.toast(this, "Не удалось запустить сервис")
        }
    }

    private fun toggleLockAll() {
        val items = Repo.load(this)
        if (items.isEmpty()) {
            Ui.toast(this, "Нет элементов")
            return
        }
        val all = items.all { it.locked }
        Repo.mutateAll(this) { it.locked = !all }
        OverlayService.refresh(false)
        updateAll()
    }

    private fun confirmDeleteAll() {
        if (Repo.load(this).isEmpty()) {
            Ui.toast(this, "Нечего удалять")
            return
        }
        AlertDialog.Builder(this)
            .setTitle("Удалить всё?")
            .setMessage("Все элементы оверлея будут удалены без возможности восстановления.")
            .setPositiveButton("Удалить") { _, _ ->
                Repo.clear(this)
                OverlayService.refresh(false)
                updateAll()
            }
            .setNegativeButton("Отмена", null)
            .show()
    }
}
