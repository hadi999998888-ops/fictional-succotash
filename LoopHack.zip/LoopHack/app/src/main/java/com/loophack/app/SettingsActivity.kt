package com.loophack.app

import android.app.Activity
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView

class SettingsActivity : Activity() {

    private fun d(v: Int) = Ui.dp(this, v)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val scroll = ScrollView(this)
        scroll.setBackgroundColor(Ui.BLACK)
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(d(16), d(20), d(16), d(32))
        scroll.addView(col, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        val head = LinearLayout(this)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        head.addView(Ui.text(this, "Настройки", 22f, Ui.WHITE, true), Ui.lin(0, Ui.WRAP, 1f))
        head.addView(Ui.chip(this, "Назад") { finish() })
        col.addView(head)

        // Рекламный щит
        val shield = Ui.card(this)
        shield.addView(
            Ui.toggle(this, "Рекламный щит LOOP HACK на оверлее", Repo.hasLogo(this)) { on ->
                if (on) {
                    if (!Repo.hasLogo(this)) Repo.addLogo(this)
                } else {
                    Repo.removeLogos(this)
                }
                OverlayService.refresh()
            }
        )
        shield.addView(Ui.text(this, "Логотип можно двигать, масштабировать и скрывать, как любой элемент.", 12f, Ui.GRAY))
        col.addView(shield, Ui.lin(Ui.MATCH, Ui.WRAP, 0f, 0, d(16), 0, 0))

        // Размер новых медиа
        val media = Ui.card(this)
        media.addView(
            Ui.seek(this, "Ширина новых фото и видео (dp)", 80, 600, Repo.mediaWidth(this), { "$it" }) {
                Repo.setMediaWidth(this, it)
            }
        )
        media.addView(Ui.text(this, "Применяется к элементам, которые вы добавите после изменения.", 12f, Ui.GRAY))
        col.addView(media, Ui.lin(Ui.MATCH, Ui.WRAP, 0f, 0, d(12), 0, 0))

        // Стрелка
        val arrow = Ui.card(this)
        arrow.addView(Ui.text(this, "Стрелка-ручка", 14f, Ui.WHITE, true))
        arrow.addView(
            Ui.text(this, "Её можно двигать пальцем влево и вправо. Здесь можно вернуть её в центр.", 12f, Ui.GRAY)
        )
        arrow.addView(
            Ui.button(this, "Вернуть стрелку в центр", 1) {
                Repo.setHandleX(this, 0.5f)
                OverlayService.relayoutMenu()
                Ui.toast(this, "Готово")
            },
            Ui.lin(Ui.MATCH, Ui.WRAP, 0f, 0, d(10), 0, 0)
        )
        col.addView(arrow, Ui.lin(Ui.MATCH, Ui.WRAP, 0f, 0, d(12), 0, 0))

        col.addView(
            Ui.button(this, "Остановить оверлеи", 1) {
                OverlayService.stop(this)
                Ui.toast(this, "Оверлеи остановлены")
            },
            Ui.lin(Ui.MATCH, Ui.WRAP, 0f, 0, d(18), 0, 0)
        )
        col.addView(Links.telegramButton(this), Ui.lin(Ui.MATCH, Ui.WRAP, 0f, 0, d(10), 0, 0))
        col.addView(
            Ui.text(this, "LOOP HACK Overlay Studio · версия 2.0", 12f, Ui.GRAY),
            Ui.lin(Ui.WRAP, Ui.WRAP, 0f, 0, d(22), 0, 0)
        )

        setContentView(scroll)
    }
}
