package com.loophack.app

import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.view.ContextThemeWrapper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.animation.AccelerateDecelerateInterpolator
import android.view.animation.DecelerateInterpolator
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/** Стрелка «вверх» для ручки. */
class ChevronView(c: Context) : View(c) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        p.strokeWidth = h * 0.11f
        val path = Path()
        path.moveTo(w * 0.32f, h * 0.64f)
        path.lineTo(w * 0.50f, h * 0.36f)
        path.lineTo(w * 0.68f, h * 0.64f)
        canvas.drawPath(path, p)
    }
}

/**
 * Две части: маленькая стрелка-ручка внизу экрана и выезжающее меню.
 * Зажать стрелку и провести вверх — меню открывается. Кнопка «—» убирает меню вниз.
 */
class OverlayMenu(
    private val svc: Context,
    private val wm: WindowManager,
    private val onStop: () -> Unit
) {
    private val ctx: Context = ContextThemeWrapper(svc, R.style.Theme_LoopHack)
    private val ui = Handler(Looper.getMainLooper())

    private fun d(v: Int) = Ui.dp(ctx, v)
    private fun screenW() = ctx.resources.displayMetrics.widthPixels
    private fun screenH() = ctx.resources.displayMetrics.heightPixels

    private val flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS

    // --- ручка ---
    private val handle = FrameLayout(ctx)
    private val pill = FrameLayout(ctx)
    private val chevron = ChevronView(ctx)
    private val handleLp = WindowManager.LayoutParams(
        d(124), d(52),
        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        flags, PixelFormat.TRANSLUCENT
    ).apply {
        gravity = Gravity.BOTTOM or Gravity.START
        y = d(72)
    }
    private var handleOn = false
    private var bob: ObjectAnimator? = null

    // --- меню ---
    private val sheet = LinearLayout(ctx)
    private val scroll = ScrollView(ctx)
    private val body = LinearLayout(ctx)
    private val sheetLp = WindowManager.LayoutParams(
        Ui.MATCH, Ui.WRAP,
        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        flags, PixelFormat.TRANSLUCENT
    ).apply {
        gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
    }
    private var sheetOn = false
    private var open = false
    private var delArmed = false

    // --- жест ручки ---
    private var downX = 0f
    private var downY = 0f
    private var startX = 0
    private var mode = 0

    init {
        buildHandle()
        buildSheet()
        relayout()
    }

    // ------------------------------------------------------------------ ручка

    private fun buildHandle() {
        pill.background = GradientDrawable(
            GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(Ui.VIOLET, Ui.PINK)
        ).apply { cornerRadius = d(16).toFloat() }
        pill.alpha = 0.8f
        pill.addView(chevron, FrameLayout.LayoutParams(Ui.MATCH, Ui.MATCH))
        handle.addView(pill, FrameLayout.LayoutParams(d(76), d(30), Gravity.CENTER))
        handle.setOnTouchListener { _, e -> onHandleTouch(e) }
    }

    private fun onHandleTouch(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = e.rawX
                downY = e.rawY
                startX = handleLp.x
                mode = 0
                pill.animate().scaleX(1.14f).scaleY(1.14f).alpha(1f).setDuration(120).start()
            }
            MotionEvent.ACTION_MOVE -> {
                val dx = e.rawX - downX
                val dy = e.rawY - downY
                if (mode == 0) {
                    if (-dy > d(34) && abs(dy) > abs(dx)) {
                        mode = 2
                        openMenu()
                    } else if (abs(dx) > d(14) && abs(dx) > abs(dy)) {
                        mode = 1
                    }
                }
                if (mode == 1) {
                    handleLp.x = (startX + dx).toInt().coerceIn(0, max(0, screenW() - handleLp.width))
                    updateLayout(handle, handleLp, handleOn)
                }
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                pill.animate().scaleX(1f).scaleY(1f).alpha(0.8f).setDuration(160).start()
                if (mode == 1) {
                    val range = max(1, screenW() - handleLp.width)
                    Repo.setHandleX(ctx, handleLp.x.toFloat() / range)
                }
                mode = 0
            }
        }
        return true
    }

    private fun showHandle() {
        if (handleOn) return
        try {
            wm.addView(handle, handleLp)
            handleOn = true
        } catch (e: Exception) {
            return
        }
        bob?.cancel()
        val a = ObjectAnimator.ofFloat(chevron, "translationY", 0f, -d(3).toFloat())
        a.duration = 900
        a.repeatCount = ValueAnimator.INFINITE
        a.repeatMode = ValueAnimator.REVERSE
        a.interpolator = AccelerateDecelerateInterpolator()
        a.start()
        bob = a
    }

    private fun hideHandle() {
        bob?.cancel()
        bob = null
        chevron.translationY = 0f
        if (!handleOn) return
        try {
            wm.removeView(handle)
        } catch (e: Exception) {
        }
        handleOn = false
    }

    // ------------------------------------------------------------------ меню

    private fun buildSheet() {
        sheet.orientation = LinearLayout.VERTICAL
        sheet.background = GradientDrawable().apply {
            setColor(0xF4120A1A.toInt())
            val r = d(26).toFloat()
            cornerRadii = floatArrayOf(r, r, r, r, 0f, 0f, 0f, 0f)
            setStroke(d(1), 0x66FF2DAA)
        }

        val head = LinearLayout(ctx)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        head.setPadding(d(16), d(12), d(12), d(8))
        head.addView(Ui.logo(ctx, 9), Ui.lin(d(32), d(32), 0f, 0, 0, d(10), 0))
        val title = Ui.text(ctx, "LOOP HACK", 17f, Ui.WHITE, true)
        title.setShadowLayer(d(8).toFloat(), 0f, 0f, Ui.PINK)
        head.addView(title, Ui.lin(0, Ui.WRAP, 1f))
        val minBtn = Ui.text(ctx, "—", 20f, Ui.WHITE, true)
        minBtn.gravity = Gravity.CENTER
        minBtn.background = Ui.rounded(Ui.PANEL2, d(12).toFloat(), 0x55B8A8C8, d(1))
        minBtn.setOnClickListener { closeMenu() }
        head.addView(minBtn, Ui.lin(d(46), d(40)))
        sheet.addView(head, Ui.lin(Ui.MATCH, Ui.WRAP))

        val line = View(ctx)
        line.background = Ui.gradient(0f)
        sheet.addView(line, Ui.lin(Ui.MATCH, d(2), 0f, d(16), 0, d(16), 0))

        scroll.isVerticalScrollBarEnabled = false
        body.orientation = LinearLayout.VERTICAL
        body.setPadding(d(14), d(10), d(14), d(40))
        scroll.addView(body, FrameLayout.LayoutParams(Ui.MATCH, Ui.WRAP))
        sheet.addView(scroll, Ui.lin(Ui.MATCH, 0, 1f))
    }

    private fun add(v: View, top: Int = 10) {
        body.addView(v, Ui.lin(Ui.MATCH, Ui.WRAP, 0f, 0, d(top), 0, 0))
    }

    private fun rebuild() {
        val y = scroll.scrollY
        body.removeAllViews()
        val items = Repo.load(ctx)

        add(Ui.sectionTitle(ctx, "ДОБАВИТЬ"), 2)
        add(
            Ui.row(
                ctx,
                Ui.button(ctx, "Aa  Текст", 0) { Nav.openEditor(ctx, null) },
                Ui.button(ctx, "Фото", 0) { Nav.pickMedia(ctx, Type.IMAGE) },
                Ui.button(ctx, "Видео", 0) { Nav.pickMedia(ctx, Type.VIDEO) }
            ), 6
        )

        val allLocked = items.isNotEmpty() && items.all { it.locked }
        val del = Ui.button(ctx, "Удалить всё", 2) { }
        del.setOnClickListener {
            if (!delArmed) {
                delArmed = true
                del.text = "Нажмите ещё раз"
                ui.postDelayed({
                    delArmed = false
                    del.text = "Удалить всё"
                }, 3000)
            } else {
                delArmed = false
                ui.removeCallbacksAndMessages(null)
                Repo.clear(ctx)
                OverlayService.refresh(false)
                rebuild()
            }
        }
        add(
            Ui.row(
                ctx,
                Ui.button(ctx, if (allLocked) "Открепить всё" else "Закрепить всё", 1) {
                    Repo.mutateAll(ctx) { it.locked = !allLocked }
                    OverlayService.refresh(false)
                    rebuild()
                },
                del
            ), 8
        )

        // Рекламный щит
        val shield = Ui.card(ctx)
        shield.addView(
            Ui.toggle(ctx, "Рекламный щит LOOP HACK", Repo.hasLogo(ctx)) { on ->
                if (on) {
                    if (!Repo.hasLogo(ctx)) Repo.addLogo(ctx)
                } else {
                    Repo.removeLogos(ctx)
                }
                OverlayService.refresh(false)
                rebuild()
            }
        )
        shield.addView(Ui.text(ctx, "Логотип на экране. Выключите, чтобы убрать, и включите, чтобы вернуть.", 12f, Ui.GRAY))
        add(shield, 12)

        // Уведомление для стримов
        add(Ui.sectionTitle(ctx, "УВЕДОМЛЕНИЕ ДЛЯ СТРИМОВ"), 16)
        add(NotifyPanel.build(ctx), 6)

        // Элементы
        add(Ui.sectionTitle(ctx, "ЭЛЕМЕНТЫ (${items.size})"), 16)
        if (items.isEmpty()) {
            add(Ui.text(ctx, "Пока пусто. Добавьте текст, фото или видео.", 13f, Ui.GRAY), 6)
        } else {
            for (item in items.reversed()) {
                add(ItemPanel.card(ctx, item) { rebuild() }, 8)
            }
        }

        add(Ui.expandable(ctx, "Инструкция", Help.INSTRUCTION), 16)
        add(Links.telegramButton(ctx), 14)
        add(Ui.button(ctx, "Остановить оверлеи", 1) { onStop() }, 8)

        scroll.post { scroll.scrollTo(0, y) }
    }

    private fun revealBody() {
        val vs = ArrayList<View>()
        for (i in 0 until min(body.childCount, 7)) vs.add(body.getChildAt(i))
        Ui.reveal(*vs.toTypedArray())
    }

    fun openMenu() {
        if (open) return
        open = true
        hideHandle()
        relayout()
        rebuild()
        sheet.translationY = sheetLp.height.toFloat()
        sheet.alpha = 0f
        try {
            wm.addView(sheet, sheetLp)
            sheetOn = true
        } catch (e: Exception) {
            open = false
            showHandle()
            return
        }
        sheet.animate()
            .translationY(0f)
            .alpha(1f)
            .setDuration(260)
            .setInterpolator(DecelerateInterpolator(1.6f))
            .start()
        revealBody()
    }

    fun closeMenu() {
        if (!open) return
        open = false
        sheet.animate()
            .translationY(sheetLp.height.toFloat())
            .alpha(0f)
            .setDuration(200)
            .withEndAction {
                detachSheet()
                if (!open) showHandle()
            }
            .start()
    }

    private fun detachSheet() {
        if (!sheetOn) return
        try {
            wm.removeView(sheet)
        } catch (e: Exception) {
        }
        sheetOn = false
    }

    // ------------------------------------------------------------------ управление

    /** Показывает стрелку (при старте сервиса). */
    fun start() {
        if (!open) showHandle()
    }

    fun refreshIfOpen() {
        if (open && sheetOn) rebuild()
    }

    /** Поднимает ручку и меню над окнами элементов. */
    fun raise() {
        try {
            if (handleOn) {
                wm.removeView(handle)
                wm.addView(handle, handleLp)
            }
            if (sheetOn) {
                wm.removeView(sheet)
                wm.addView(sheet, sheetLp)
            }
        } catch (e: Exception) {
        }
    }

    fun relayout() {
        val w = screenW()
        val h = screenH()
        val land = w > h
        sheetLp.width = min(w, d(560))
        sheetLp.height = (h * (if (land) 0.92f else 0.64f)).toInt()
        handleLp.x = (Repo.handleX(ctx) * max(0, w - handleLp.width)).toInt()
        updateLayout(handle, handleLp, handleOn)
        updateLayout(sheet, sheetLp, sheetOn)
    }

    private fun updateLayout(v: View, lp: WindowManager.LayoutParams, on: Boolean) {
        if (!on) return
        try {
            wm.updateViewLayout(v, lp)
        } catch (e: Exception) {
        }
    }

    fun destroy() {
        ui.removeCallbacksAndMessages(null)
        bob?.cancel()
        bob = null
        sheet.animate().cancel()
        if (handleOn) {
            try {
                wm.removeView(handle)
            } catch (e: Exception) {
            }
            handleOn = false
        }
        detachSheet()
        open = false
    }
}
